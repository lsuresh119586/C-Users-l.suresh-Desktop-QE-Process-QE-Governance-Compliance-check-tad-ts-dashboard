# Sprint 26.1.1 - Team Test Case Summary

**Report Date:** January 13, 2026  
**Data Source:** qTest Project ID 114345

## Test Case Distribution by Team

| Sprint Team | No. of Automated | No. of Not Automated | Total Test Cases | Automation % |
|-------------|------------------|---------------------|------------------|--------------|
| Vanguards | 0 | 23 | 23 | 0.0% |
| Nexus | 0 | 0 | 0 | N/A |
| Chubb | 0 | 19 | 19 | 0.0% |
| Matrix | 8 | 3 | 11 | 72.7% |
| Chargers | 1 | 2 | 3 | 33.3% |
| Mavericks | 12 | 10 | 22 | 54.5% |
| **TOTAL** | **21** | **57** | **78** | **26.9%** |

---

## Summary Statistics

- **Total Test Cases Created:** 78
- **Automated Test Cases:** 21 (26.9%)
- **Manual Test Cases:** 57 (73.1%)
- **Teams with Test Cases:** 5 out of 6 (Nexus Sprint 26.1.1 has no cases yet)


---

## Team Rankings

### By Total Test Cases
1. Vanguards - 23 test cases (29.5% of total)
2. Mavericks - 22 test cases (28.2% of total)
3. Chubb - 19 test cases (24.4% of total)
4. Matrix - 11 test cases (14.1% of total)
5. Chargers - 3 test cases (3.8% of total)
6. Nexus - 0 test cases (0% of total)

### By Automation Percentage
1. Matrix - 72.7% (8 out of 11)
2. Mavericks - 54.5% (12 out of 22)
3. Chargers - 33.3% (1 out of 3)
4. Vanguards - 0.0% (0 out of 23)
5. Chubb - 0.0% (0 out of 19)
6. Nexus - N/A (no test cases)

### By Automated Test Cases Volume
1. Mavericks - 12 automated cases
2. Matrix - 8 automated cases
3. Chargers - 1 automated case
4. Vanguards - 0 automated cases
5. Chubb - 0 automated cases
6. Nexus - 0 automated cases

---

## Detailed Breakdown by Team

### Vanguards (23 cases - 0% automated)
- **Module:** Sprint 26.1.1 parent folder (68182935)
- **Story:** GET-62908 - Invoice AI Payloads
- **Status:** All manual test cases
- **Test Coverage:** Budget/adjustment validation, payload generation, performance testing, edge cases, audit logging

### Nexus (0 cases)
- **Module:** Sprint 26.1.1 parent folder (68053478)
- **Status:** No test cases found in Sprint 26.1.1 folder
- **Note:** Team may have test cases in other sprint folders or modules

### Chubb (19 cases - 0% automated)
- **Module:** Sprint 26.1.1 parent folder (68181234)
- **Stories:** Multiple - Affiliated Vendor, Predictive Insights, ITP Rules
- **Status:** All manual test cases
- **Test Coverage:** Data exchange, authority approval, rescoring, ITP rules validation

### Matrix (11 cases - 72.7% automated)
- **Module 1:** GET-66026 (68186055) - 8 cases (all automated with Tosca)
- **Module 2:** GET-67182 (68189214) - 3 cases (all automated with Tosca)
- **Status:** Leading team in automation percentage
- **Test Coverage:** Menu visibility, service enablement, JAMS to Scheduler migration

### Chargers (3 cases - 33.3% automated)
- **Module 1:** GET-65980 (68196214) - 1 case (manual)
- **Module 2:** GET-65633 (68189034) - 2 cases (manual)
- **Status:** Small module with .NET 9.0 upgrade and document migration
- **Test Coverage:** DDD template upgrade, dual write mode migration

### Mavericks (22 cases - 54.5% automated)
- **Module 1:** GET-60431 (68195895) - 6 cases (all automated with Tosca)
- **Module 2:** GET-62132 (68195898) - 10 cases (all manual)
- **Module 3:** GET-61996 (68196337) - 6 cases (all automated with Tosca)
- **Status:** Good automation coverage with 12 automated cases
- **Test Coverage:** AI Assistant label updates, customer configuration management, global search special characters

---

## Key Insights

### Automation Leaders
- **Matrix** leads with 72.7% automation (8/11 cases automated with Tosca)
- **Mavericks** achieves 54.5% automation (12/22 cases automated with Tosca)
- **Chargers** has 33.3% automation (1/3 cases)

### Automation Opportunities
- **Vanguards**: 23 manual test cases (0% automated) - largest opportunity for automation
- **Chubb**: 19 manual test cases (0% automated) - significant automation gap
- Combined: 42 manual test cases ready for automation evaluation

### Test Case Distribution
- **Vanguards** has the largest volume (29.5% of total) but no automation
- **Mavericks** has balanced volume (28.2%) with good automation (54.5%)
- **Nexus** Sprint 26.1.1 folder has no test cases - may need investigation

---

## Module Reference Guide

| Team | Module ID | Module Name | Test Cases | Automation |
|------|-----------|-------------|------------|------------|
| Vanguards | 68182935 | Sprint 26.1.1 (parent) | 23 | 0 |
| Nexus | 68053478 | Sprint 26.1.1 (parent) | 0 | 0 |
| Chubb | 68181234 | Sprint 26.1.1 (parent) | 19 | 0 |
| Matrix | 68186055 | GET-66026 | 8 | 8 |
| Matrix | 68189214 | GET-67182 | 3 | 3 |
| Chargers | 68196214 | GET-65980 | 1 | 0 |
| Chargers | 68189034 | GET-65633 | 2 | 0 |
| Mavericks | 68195895 | GET-60431 | 6 | 6 |
| Mavericks | 68195898 | GET-62132 | 10 | 0 |
| Mavericks | 68196337 | GET-61996 | 6 | 6 |

---

**Project:** T360 Web and OC (Project ID: 114345)  
**Environment:** qtestnet.com  
**Query Date:** January 13, 2026
