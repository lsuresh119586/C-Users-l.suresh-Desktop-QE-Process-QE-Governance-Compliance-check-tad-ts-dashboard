#!/usr/bin/env python3
"""
Sprint TAD/TS Compliance Report
Analyzes all cards in a JIRA sprint and checks for TAD and TS deliverables
"""

import requests
import json
import sys
from datetime import datetime
import csv
import time
import re
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

JIRA_URL = "https://jira.wolterskluwer.io/jira"
JIRA_API_TOKEN = "MjU3ODY5NTM2NjcyOjwxP4u0OS5CY5BcY65ot91tUcwn"
PROJECT_KEY = "ELM"

def get_session():
    """Create authenticated JIRA session with retry logic"""
    session = requests.Session()
    
    # Configure retry strategy
    retry_strategy = Retry(
        total=3,
        backoff_factor=1,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["HEAD", "GET", "POST", "OPTIONS"]
    )
    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    
    session.headers.update({
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": f"Bearer {JIRA_API_TOKEN}"
    })
    return session

def get_sprint_issues_by_jql(session, from_date=None, to_date=None):
    """Get all issues in a date range using JQL"""
    
    if from_date and to_date:
        # Search by date range
        jql = f'project = {PROJECT_KEY} AND updated >= "{from_date}" AND updated <= "{to_date}" ORDER BY updated DESC'
    elif from_date:
        # From date only
        jql = f'project = {PROJECT_KEY} AND updated >= "{from_date}" ORDER BY updated DESC'
    else:
        # Get current/recent sprint
        jql = f'project = {PROJECT_KEY} AND sprint in openSprints() ORDER BY updated DESC'
    
    url = f"{JIRA_URL}/rest/api/2/search"
    
    all_issues = []
    start_at = 0
    max_results = 100
    
    while True:
        payload = {
            "jql": jql,
            "startAt": start_at,
            "maxResults": max_results,
            "fields": ["summary", "description", "status", "assignee", "issuetype", "priority", "sprint", "customfield_13392"]
        }
        
        response = session.post(url, json=payload)
        
        if not response.ok:
            print(f"❌ Error fetching issues: {response.status_code}")
            print(f"Response: {response.text[:200]}")
            break
        
        data = response.json()
        issues = data.get('issues', [])
        all_issues.extend(issues)
        
        if len(issues) < max_results:
            break
        
        start_at += max_results
    
    return all_issues

def check_deliverables(session, issue_key, issue_id, description=None):
    """Check if issue has TAD and TS PRs or documentation links in description"""
    dev_status_url = f"{JIRA_URL}/rest/dev-status/1.0/issue/detail"
    
    result = {
        "tad_found": False,
        "ts_found": False,
        "tad_pr": None,
        "ts_pr": None,
        "total_prs": 0,
        "tad_source": None,
        "ts_source": None,
        "tad_desc_links": [],
        "ts_desc_links": []
    }
    
    # Add small delay to avoid rate limiting
    time.sleep(0.3)
    
    # Check Bitbucket
    for app_type in ['stash', 'github', 'gitlab']:
        dev_params = {
            'issueId': issue_id,
            'applicationType': app_type,
            'dataType': 'pullrequest'
        }
        
        try:
            dev_response = session.get(dev_status_url, params=dev_params, timeout=10)
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as e:
            print(f"⚠️  Connection error for {issue_key}: {str(e)[:50]}...")
            continue
        
        if dev_response.ok:
            try:
                dev_data = dev_response.json()
                details = dev_data.get('detail', [])
                
                for detail in details:
                    prs = detail.get('pullRequests', [])
                    result['total_prs'] += len(prs)
                    
                    for pr in prs:
                        pr_name = pr.get('name', '').upper()
                        pr_status = pr.get('status', 'Unknown')
                        pr_url = pr.get('url', '')
                        
                        # Check for TAD
                        if 'TAD' in pr_name or 'TECHNICAL ARCHITECTURE' in pr_name:
                            result['tad_found'] = True
                            result['tad_pr'] = {
                                "name": pr.get('name', ''),
                                "status": pr_status,
                                "url": pr_url
                            }
                        
                        # Check for TS
                        if ('TS FOR' in pr_name or 'TEST STRATEGY' in pr_name) and 'TS FILE' not in pr_name:
                            result['ts_found'] = True
                            result['ts_pr'] = {
                                "name": pr.get('name', ''),
                                "status": pr_status,
                                "url": pr_url
                            }
            except:
                pass
    
    # Store PR source if found
    if result['tad_found']:
        result['tad_source'] = 'PR'
    if result['ts_found']:
        result['ts_source'] = 'PR'
    
    # Also check description if provided
    if description:
        desc_result = check_description_for_links(description)
        
        # Combine PR results with description results
        if not result['tad_found'] and desc_result['tad_in_desc']:
            result['tad_found'] = True
            result['tad_source'] = 'Description'
            result['tad_desc_links'] = desc_result['tad_links']
        
        if not result['ts_found'] and desc_result['ts_in_desc']:
            result['ts_found'] = True
            result['ts_source'] = 'Description'
            result['ts_desc_links'] = desc_result['ts_links']
    
    return result

def check_description_for_links(description):
    """
    Check if description contains TAD/TS documentation links
    
    Args:
        description: JIRA issue description text
        
    Returns:
        dict with tad_in_desc, ts_in_desc, tad_links, ts_links
    """
    result = {
        'tad_in_desc': False,
        'ts_in_desc': False,
        'tad_links': [],
        'ts_links': []
    }
    
    if not description:
        return result
    
    desc_upper = description.upper()
    
    # Keywords for TAD
    tad_keywords = [
        'TECHNICAL ARCHITECTURE',
        'TAD DOCUMENT',
        'ADR',  # Architecture Decision Record
        'ARCHITECTURE DECISION',
        'DESIGN DOCUMENT',
        'TECHNICAL DESIGN'
    ]
    
    # Keywords for TS
    ts_keywords = [
        'TEST STRATEGY',
        'TS FOR',
        'TEST PLAN',
        'TESTING STRATEGY',
        'QA STRATEGY'
    ]
    
    # Check for TAD keywords
    for keyword in tad_keywords:
        if keyword in desc_upper:
            result['tad_in_desc'] = True
            # Extract URLs from description
            urls = re.findall(r'https?://[^\s\]\)]+', description)
            result['tad_links'] = urls[:5]  # Limit to first 5 URLs
            break
    
    # Check for TS keywords  
    for keyword in ts_keywords:
        if keyword in desc_upper and 'TS FILE' not in desc_upper:
            result['ts_in_desc'] = True
            # Extract URLs
            urls = re.findall(r'https?://[^\s\]\)]+', description)
            result['ts_links'] = urls[:5]  # Limit to first 5 URLs
            break
    
    return result

def generate_report(session, sprint_name, issues_data):
    """Generate consolidated report"""
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    timestamp_display = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    report_file = f"sprint_tad_ts_report_{timestamp}.csv"
    md_report_file = f"sprint_tad_ts_report_{timestamp}.md"
    json_report_file = "tad-ts-report-data.json"  # Fixed name for dashboard
    js_report_file = "tad-ts-report-data.js"  # JavaScript version to bypass CORS
    
    # Extract month from sprint_name for month-specific files
    # sprint_name format: "2025-12-01 to 2025-12-31"
    month_match = sprint_name.split(' to ')[0][:7] if ' to ' in sprint_name else None
    if month_match:
        month_json_file = f"tad-ts-report-{month_match}.json"
        month_js_file = f"tad-ts-report-{month_match}.js"
    else:
        month_json_file = None
        month_js_file = None
    
    # Calculate statistics
    total = len(issues_data)
    tad_complete = sum(1 for i in issues_data if i['tad_found'])
    ts_complete = sum(1 for i in issues_data if i['ts_found'])
    both_complete = sum(1 for i in issues_data if i['tad_found'] and i['ts_found'])
    missing_tad = sum(1 for i in issues_data if not i['tad_found'])
    missing_ts = sum(1 for i in issues_data if not i['ts_found'])
    
    # Console output
    print(f"\n{'='*80}")
    print(f"SPRINT TAD/TS COMPLIANCE REPORT")
    print(f"{'='*80}")
    print(f"Sprint: {sprint_name}")
    print(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*80}\n")
    
    print(f"📊 SUMMARY")
    print(f"-" * 80)
    print(f"Total Issues: {total}")
    print(f"TAD Complete: {tad_complete} ({tad_complete/total*100:.1f}%)")
    print(f"TS Complete: {ts_complete} ({ts_complete/total*100:.1f}%)")
    print(f"Both Complete: {both_complete} ({both_complete/total*100:.1f}%)")
    print(f"Missing TAD: {missing_tad}")
    print(f"Missing TS: {missing_ts}")
    print(f"\n")
    
    # Detailed table
    print(f"📋 DETAILED BREAKDOWN")
    print(f"-" * 80)
    print(f"{'Issue':<15} {'Type':<15} {'Status':<15} {'TAD':<8} {'TS':<8} {'PRs':<5}")
    print(f"-" * 80)
    
    for issue in issues_data:
        tad_status = "✅" if issue['tad_found'] else "❌"
        ts_status = "✅" if issue['ts_found'] else "❌"
        
        print(f"{issue['key']:<15} {issue['type']:<15} {issue['status']:<15} "
              f"{tad_status:<8} {ts_status:<8} {issue['total_prs']:<5}")
    
    print(f"\n")
    
    # Issues missing TAD
    missing_tad_issues = [i for i in issues_data if not i['tad_found']]
    if missing_tad_issues:
        print(f"⚠️  ISSUES MISSING TAD ({len(missing_tad_issues)})")
        print(f"-" * 80)
        for issue in missing_tad_issues:
            print(f"  • {issue['key']}: {issue['summary']}")
        print()
    
    # Issues missing TS
    missing_ts_issues = [i for i in issues_data if not i['ts_found']]
    if missing_ts_issues:
        print(f"⚠️  ISSUES MISSING TS ({len(missing_ts_issues)})")
        print(f"-" * 80)
        for issue in missing_ts_issues:
            print(f"  • {issue['key']}: {issue['summary']}")
        print()
    
    # Save CSV report
    with open(report_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['Issue Key', 'Summary', 'Type', 'Status', 'Team', 'Assignee',
                        'TAD Found', 'TAD Source', 'TAD PR', 'TAD Status', 'TAD URL',
                        'TS Found', 'TS Source', 'TS PR', 'TS Status', 'TS URL',
                        'Total PRs', 'TAD Desc Links', 'TS Desc Links'])
        
        for issue in issues_data:
            tad_pr = issue.get('tad_pr', {}) or {}
            ts_pr = issue.get('ts_pr', {}) or {}
            
            writer.writerow([
                issue['key'],
                issue['summary'],
                issue['type'],
                issue['status'],
                issue['team'],
                issue['assignee'],
                'Yes' if issue['tad_found'] else 'No',
                issue.get('tad_source', ''),
                tad_pr.get('name', ''),
                tad_pr.get('status', ''),
                tad_pr.get('url', ''),
                'Yes' if issue['ts_found'] else 'No',
                issue.get('ts_source', ''),
                ts_pr.get('name', ''),
                ts_pr.get('status', ''),
                ts_pr.get('url', ''),
                issue['total_prs'],
                '; '.join(issue.get('tad_desc_links', [])[:2]),
                '; '.join(issue.get('ts_desc_links', [])[:2])
            ])
    
    # Save Markdown report
    with open(md_report_file, 'w', encoding='utf-8') as f:
        f.write(f"# Sprint TAD/TS Compliance Report\n\n")
        f.write(f"**Sprint:** {sprint_name}  \n")
        f.write(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  \n\n")
        
        f.write(f"## Summary\n\n")
        f.write(f"| Metric | Count | Percentage |\n")
        f.write(f"|--------|-------|------------|\n")
        f.write(f"| Total Issues | {total} | 100% |\n")
        f.write(f"| TAD Complete | {tad_complete} | {tad_complete/total*100:.1f}% |\n")
        f.write(f"| TS Complete | {ts_complete} | {ts_complete/total*100:.1f}% |\n")
        f.write(f"| Both Complete | {both_complete} | {both_complete/total*100:.1f}% |\n")
        f.write(f"| Missing TAD | {missing_tad} | {missing_tad/total*100:.1f}% |\n")
        f.write(f"| Missing TS | {missing_ts} | {missing_ts/total*100:.1f}% |\n\n")
        
        # Group issues by team
        from collections import defaultdict
        teams = defaultdict(list)
        for issue in issues_data:
            teams[issue['team']].append(issue)
        
        # Summary by team
        f.write(f"## Summary by Team\n\n")
        f.write(f"| Team | Total | TAD | TS | Both | TAD % | TS % |\n")
        f.write(f"|------|-------|-----|----|----|-------|------|\n")
        
        for team_name in sorted(teams.keys()):
            team_issues = teams[team_name]
            team_total = len(team_issues)
            team_tad = sum(1 for i in team_issues if i['tad_found'])
            team_ts = sum(1 for i in team_issues if i['ts_found'])
            team_both = sum(1 for i in team_issues if i['tad_found'] and i['ts_found'])
            team_tad_pct = (team_tad / team_total * 100) if team_total > 0 else 0
            team_ts_pct = (team_ts / team_total * 100) if team_total > 0 else 0
            
            f.write(f"| {team_name} | {team_total} | {team_tad} | {team_ts} | {team_both} | ")
            f.write(f"{team_tad_pct:.1f}% | {team_ts_pct:.1f}% |\n")
        
        f.write("\n")
        
        # Detailed breakdown by team
        for team_name in sorted(teams.keys()):
            team_issues = teams[team_name]
            f.write(f"## Team: {team_name} ({len(team_issues)} issues)\n\n")
            f.write(f"| Issue | Type | Status | TAD | TS | PRs | Summary |\n")
            f.write(f"|-------|------|--------|-----|----|----|----------|\n")
            
            for issue in team_issues:
                tad = "✅" if issue['tad_found'] else "❌"
                ts = "✅" if issue['ts_found'] else "❌"
                f.write(f"| {issue['key']} | {issue['type']} | {issue['status']} | ")
                f.write(f"{tad} | {ts} | {issue['total_prs']} | {issue['summary'][:50]} |\n")
            
            f.write("\n")
        
        if missing_tad_issues:
            f.write(f"\n## ⚠️ Issues Missing TAD\n\n")
            for issue in missing_tad_issues:
                f.write(f"- **{issue['key']}**: {issue['summary']}\n")
        
        if missing_ts_issues:
            f.write(f"\n## ⚠️ Issues Missing TS\n\n")
            for issue in missing_ts_issues:
                f.write(f"- **{issue['key']}**: {issue['summary']}\n")
    
    # Generate JSON for dashboard
    dashboard_data = {
        "dateRange": sprint_name,
        "generated": timestamp_display,
        "summary": {
            "total": total,
            "tadComplete": tad_complete,
            "tsComplete": ts_complete,
            "bothComplete": both_complete,
            "missingTad": missing_tad,
            "missingTs": missing_ts,
            "tadPct": (tad_complete / total * 100) if total > 0 else 0,
            "tsPct": (ts_complete / total * 100) if total > 0 else 0,
            "bothPct": (both_complete / total * 100) if total > 0 else 0,
            "missingTadPct": (missing_tad / total * 100) if total > 0 else 0,
            "missingTsPct": (missing_ts / total * 100) if total > 0 else 0
        },
        "teams": {}
    }
    
    # Add team data
    for team_name in teams.keys():
        team_issues = teams[team_name]
        team_total = len(team_issues)
        team_tad = sum(1 for i in team_issues if i['tad_found'])
        team_ts = sum(1 for i in team_issues if i['ts_found'])
        team_both = sum(1 for i in team_issues if i['tad_found'] and i['ts_found'])
        
        dashboard_data["teams"][team_name] = {
            "total": team_total,
            "tadComplete": team_tad,
            "tsComplete": team_ts,
            "bothComplete": team_both,
            "tadPct": (team_tad / team_total * 100) if team_total > 0 else 0,
            "tsPct": (team_ts / team_total * 100) if team_total > 0 else 0,
            "issues": [
                {
                    "key": issue['key'],
                    "summary": issue['summary'],
                    "type": issue['type'],
                    "status": issue['status'],
                    "tadFound": issue['tad_found'],
                    "tsFound": issue['ts_found'],
                    "totalPrs": issue['total_prs']
                }
                for issue in team_issues
            ]
        }
    
    with open(json_report_file, 'w', encoding='utf-8') as f:
        json.dump(dashboard_data, f, indent=2)
    
    # Also create JavaScript version to bypass CORS issues
    with open(js_report_file, 'w', encoding='utf-8') as f:
        f.write('window.reportData = ')
        json.dump(dashboard_data, f, indent=2)
        f.write(';')
    
    # Save month-specific files for dashboard month selector
    if month_json_file:
        with open(month_json_file, 'w', encoding='utf-8') as f:
            json.dump(dashboard_data, f, indent=2)
        with open(month_js_file, 'w', encoding='utf-8') as f:
            f.write('window.reportData = ')
            json.dump(dashboard_data, f, indent=2)
            f.write(';')
    
    print(f"{'='*80}")
    print(f"✅ Reports saved:")
    print(f"   📄 CSV: {report_file} (will be deleted)")
    print(f"   📄 Markdown: {md_report_file} (will be deleted)")
    print(f"   📊 Dashboard JSON: {json_report_file}")
    print(f"   📊 Dashboard JS: {js_report_file}")
    if month_json_file:
        print(f"   📊 Month JSON: {month_json_file}")
        print(f"   📊 Month JS: {month_js_file}")
    print(f"   🌐 Open: tad-ts-dashboard.html")
    
    # Delete CSV and MD files after JSON/JS files are generated
    import os
    try:
        if os.path.exists(report_file):
            os.remove(report_file)
            print(f"   🗑️  Deleted: {report_file}")
        if os.path.exists(md_report_file):
            os.remove(md_report_file)
            print(f"   🗑️  Deleted: {md_report_file}")
    except Exception as e:
        print(f"   ⚠️  Error deleting files: {e}")
    
    print(f"{'='*80}\n")

def main():
    """Main execution"""
    
    session = get_session()
    
    # Get date range from arguments or use current sprint
    from_date = None
    to_date = None
    report_title = "Current Sprint"
    
    if len(sys.argv) >= 3:
        from_date = sys.argv[1]
        to_date = sys.argv[2]
        report_title = f"{from_date} to {to_date}"
        print(f"\n🔍 Fetching issues updated between {from_date} and {to_date}...")
    elif len(sys.argv) == 2:
        from_date = sys.argv[1]
        report_title = f"From {from_date}"
        print(f"\n🔍 Fetching issues updated from {from_date}...")
    else:
        print(f"\n🔍 Fetching issues from current/open sprints...")
    
    # Get issues
    issues = get_sprint_issues_by_jql(session, from_date, to_date)
    
    if not issues:
        print("❌ No issues found")
        print("\nUsage:")
        print("  py sprint-tad-ts-report.py                           # Check current sprint")
        print("  py sprint-tad-ts-report.py 2025-12-01 2025-12-31    # Check date range")
        print("  py sprint-tad-ts-report.py 2025-12-01                # Check from date")
        return
    
    print(f"✅ Found {len(issues)} issues")
    print(f"🔍 Checking TAD/TS deliverables for each issue...\n")
    
    # Process each issue
    issues_data = []
    
    for idx, issue in enumerate(issues, 1):
        key = issue['key']
        fields = issue['fields']
        
        print(f"  [{idx}/{len(issues)}] Checking {key}...", end="\r")
        
        # Extract description and issue type
        description = fields.get('description', '')
        issue_type = fields.get('issuetype', {}).get('name', 'Unknown')
        
        # Only check for TAD/TS PRs if issue type is Bug or Story
        if issue_type in ['Bug', 'Story']:
            deliverables = check_deliverables(session, key, issue['id'], description)
        else:
            # Skip PR check for other types (Sub-task, etc.)
            deliverables = {
                'tad_found': False,
                'ts_found': False,
                'tad_pr': None,
                'ts_pr': None,
                'total_prs': 0
            }
        
        # Extract team name from customfield_13392
        team = 'Unknown Team'
        if fields.get('customfield_13392'):
            team_field = fields['customfield_13392']
            if isinstance(team_field, dict):
                team = team_field.get('value', 'Unknown Team')
            else:
                team = str(team_field)
        
        issues_data.append({
            'key': key,
            'summary': fields.get('summary', 'No summary'),
            'type': issue_type,
            'team': team,
            'status': fields.get('status', {}).get('name', 'Unknown'),
            'assignee': fields.get('assignee', {}).get('displayName', 'Unassigned') if fields.get('assignee') else 'Unassigned',
            'tad_found': deliverables['tad_found'],
            'ts_found': deliverables['ts_found'],
            'tad_pr': deliverables['tad_pr'],
            'ts_pr': deliverables['ts_pr'],
            'total_prs': deliverables['total_prs'],
            'tad_source': deliverables.get('tad_source'),
            'ts_source': deliverables.get('ts_source'),
            'tad_desc_links': deliverables.get('tad_desc_links', []),
            'ts_desc_links': deliverables.get('ts_desc_links', [])
        })
    
    print()  # New line after progress
    
    # Filter to only include Bug and Story types in the report
    filtered_issues_data = [issue for issue in issues_data if issue['type'] in ['Bug', 'Story']]
    
    print(f"ℹ️  Filtered to {len(filtered_issues_data)} Bug/Story issues out of {len(issues_data)} total issues")
    
    # Generate report
    generate_report(session, report_title, filtered_issues_data)

if __name__ == "__main__":
    main()
