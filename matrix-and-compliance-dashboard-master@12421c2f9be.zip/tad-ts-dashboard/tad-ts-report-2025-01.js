window.reportData = {
  "dateRange": "2025-01-01 to 2025-01-31",
  "generated": "2026-01-08 09:32:30",
  "summary": {
    "total": 138,
    "tadComplete": 1,
    "tsComplete": 16,
    "bothComplete": 0,
    "missingTad": 137,
    "missingTs": 122,
    "tadPct": 0.7246376811594203,
    "tsPct": 11.594202898550725,
    "bothPct": 0.0,
    "missingTadPct": 99.27536231884058,
    "missingTsPct": 88.40579710144928
  },
  "teams": {
    "Unknown Team": {
      "total": 12,
      "tadComplete": 0,
      "tsComplete": 0,
      "bothComplete": 0,
      "tadPct": 0.0,
      "tsPct": 0.0,
      "issues": [
        {
          "key": "ELM-25138",
          "summary": "   POC - Create dedicated node pool deployment of Cognos ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-21382",
          "summary": "PRB0056430/PTASK0032303 - Ensure we have enough storage to maintain glowroot traces",
          "type": "Story",
          "status": "Resolved",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-11916",
          "summary": "Remediation: DNS Record Deletion",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-8090",
          "summary": "Copy the query result data into a CSV file through Jenkins Job.",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27742",
          "summary": "   PreExisting: Dashboard_ Download PDF document not working  ",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-20921",
          "summary": "Migrate Key Vault Access Policy to Azure Role-Based Access Control (RBAC)",
          "type": "Story",
          "status": "Resolved",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27476",
          "summary": "   Large size file upload displays alert message instead proper error message ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-19619",
          "summary": "Upgrade whsender service to .NET 8.0 due to .NET 5.0 end-of-support.",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 2
        },
        {
          "key": "ELM-19620",
          "summary": "Upgrade whsubscription service to .NET 8.0 due to .NET 5.0 end-of-support.",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-21381",
          "summary": "PRB0056430 - Document the FDIC Incident response escalation path",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-16608",
          "summary": "2024 FDIC FISMA POAM - Sensitive Data Exposure",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-23364",
          "summary": "PRB0056618 - PTASK0032155 Adjust the job schedule to run at 12AM EU time as most of DWS customers are in EU. Currently the job is set to run 12AM Friday EST.",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        }
      ]
    },
    "QA Perf Testing": {
      "total": 13,
      "tadComplete": 0,
      "tsComplete": 2,
      "bothComplete": 0,
      "tadPct": 0.0,
      "tsPct": 15.384615384615385,
      "issues": [
        {
          "key": "ELM-27869",
          "summary": "   T360 | GET-28746 | Sprint Performance Test for navigation inside IAMR Gadget  ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27509",
          "summary": "   T360 | Refactor Invoice Review, Approval, Rollback, and Process Scripts",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27086",
          "summary": "   Passport| Starbucks previous testing requirement and result analysis for upcoming project ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-26883",
          "summary": "   Passport| ELM-26375| eDOCS \u2013 Oauth2 Support:|requirement understanding",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27506",
          "summary": "   T360 | Quick Search in GB & CHUBB Network ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27315",
          "summary": "   T360 | 25.1.1 | Release Test Executions ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-25805",
          "summary": "   T360 | TPA Review Setup in Perf ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-26820",
          "summary": "   T360 | Script Validations with Jan 2025 New Prod DB Backup in Perf ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-26896",
          "summary": "   T360 -Perf Env readiness for Release Testing ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27083",
          "summary": "CP|ELM-26297|Sharedoc Windows2012 box - Upgrade to Windows22 - LNP CP LegacyInvoiceValidation |Test Plan preparation ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-25597",
          "summary": "   Passport|BasePassportRequirement understandinga nd Test plan prep for ELM-21362Invoice Management Improvements: Total amount of invoice not displayed in invoice details ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-25598",
          "summary": "   Passport|Citi|Requiremnt understanding of ELM-18863-Critical Performance Item -Async takes over an hour to process 1000 events ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-26648",
          "summary": "   T360 | Sprint Performance Validations for GET-24615, GET-36046, GET-31625 ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        }
      ]
    },
    "Nike": {
      "total": 7,
      "tadComplete": 0,
      "tsComplete": 0,
      "bothComplete": 0,
      "tadPct": 0.0,
      "tsPct": 0.0,
      "issues": [
        {
          "key": "ELM-27773",
          "summary": "   Python deployment - Pipeline are not failing if project folder doesn't exists in postprocessing. ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27699",
          "summary": "   Qlik compose - Connection details in Legalhold are referring to passport DB ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27627",
          "summary": "   Qlik compose - Program files are not referring to compose project created by pipeline ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-22848",
          "summary": "list of vizzes in the detail, not reacting to vendor filter - C00348",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27087",
          "summary": "   Python build and deploy pipeline - not configurable in few files ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-26891",
          "summary": "   LVD: GB dashboard are not loading due to certificate issue ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-24916",
          "summary": "   Citigroup - QA/Q1 Environment - Legalhold tables are missing primary keys ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 7
        }
      ]
    },
    "Guardians": {
      "total": 5,
      "tadComplete": 0,
      "tsComplete": 0,
      "bothComplete": 0,
      "tadPct": 0.0,
      "tsPct": 0.0,
      "issues": [
        {
          "key": "ELM-27578",
          "summary": "   zuse1pqlik01 All Error PH0069 ",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-25710",
          "summary": "    Cognos upgrading is getting Fail for the version 11.2.4 ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-26667",
          "summary": "Cognos 11.2.4 Upgrade failed because of namespace issue ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-26817",
          "summary": "   Cognos 11.2.4 inconsistency in button  ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27113",
          "summary": "   Summary Tables initial load failed as it could not find Invoice_Level_Summary_Initialload.sql ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        }
      ]
    },
    "PP Pinnacles": {
      "total": 29,
      "tadComplete": 0,
      "tsComplete": 1,
      "bothComplete": 0,
      "tadPct": 0.0,
      "tsPct": 3.4482758620689653,
      "issues": [
        {
          "key": "ELM-25084",
          "summary": "  [jQuery Upgrade] -  Bulk Update jQuery to 3.7.1 - CSS Attributes/Arrays",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 3
        },
        {
          "key": "ELM-26572",
          "summary": "   [jQuery Upgrade] -  Bulk Update jQuery to 3.7.1 - Ajax, HTML, JSON ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 3
        },
        {
          "key": "ELM-27000",
          "summary": "   508 Accessibility feature - Purple focus not visible though 508 enabled in the UI ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 2
        },
        {
          "key": "ELM-27035",
          "summary": "      Voyager Fixture Issue - Fixture not identifying the popup to close  ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-25088",
          "summary": "  [jQuery Upgrade] -  Replace jQuery Cookie plugin ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 4
        },
        {
          "key": "ELM-25087",
          "summary": " [jQuery Upgrade] - Upgrade jQuery Color Animations ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 2
        },
        {
          "key": "ELM-27416",
          "summary": "      Tools window remains accessible when Save Current View pop-up is open under Documents Summary tab.    ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 2
        },
        {
          "key": "ELM-27452",
          "summary": "   In Create object screen while adding multiple Attributes when the Add button goes on top of screen and is not viewable, on scrolling up the scroll bar for the first time its flickering and not moving. ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 2
        },
        {
          "key": "ELM-25296",
          "summary": "   SonarQube Framework : Security Medium- Potential Path Traversal (file write) ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-25280",
          "summary": "   SonarQube Framework : Security Medium- Potential Path Traversal (file read) ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-26241",
          "summary": "   [jQuery Upgrade] -  Bulk Update jQuery to 3.7.1 - Events",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 5
        },
        {
          "key": "ELM-25965",
          "summary": "  [jQuery Upgrade] -  Bulk Update jQuery to 3.7.1 - Core/DOM",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 3
        },
        {
          "key": "ELM-25847",
          "summary": "  [jQuery Upgrade] -  Bulk Update jQuery to 3.7.1 - jQuery UI",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 11
        },
        {
          "key": "ELM-25704",
          "summary": "[jQuery Upgrade] - Fix jquery-migrate-1.1.1 deprecate warnings  ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-25083",
          "summary": "  [jQuery Upgrade] -  Bulk Update Jquery to 1.12.4 ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-25298",
          "summary": "   SonarQube Framework : Security Medium- Predictable pseudorandom number generator ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-25292",
          "summary": "   SonarQube Framework : Security Medium-  Hard coded password ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-25277",
          "summary": "   SonarQube Framework : Security High - A malicious XSLT could be provided ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-25278",
          "summary": "   SonarQube Framework : Security High - Potential Command Injection ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27056",
          "summary": "   In the application, the close icon ('X') on the select popup is being replaced by a search icon when the mouse hovers over it ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 4
        },
        {
          "key": "ELM-26991",
          "summary": "   User - Add/Cancel button not working while creating User ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 2
        },
        {
          "key": "ELM-26974",
          "summary": "   Caret Icon is missing in the Matter and Invoice item screen ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 2
        },
        {
          "key": "ELM-26973",
          "summary": "   Document: Unable to view the added documents in the list  ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 2
        },
        {
          "key": "ELM-26986",
          "summary": "   For Matter creation , after clicking the Save/Cancel button the cursor is spinning for long time. ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 2
        },
        {
          "key": "ELM-27016",
          "summary": "   Under organization subtab in People tab, the data entered in Dept/BU Textbox is  not saved on clicking the Main save button ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 2
        },
        {
          "key": "ELM-27010",
          "summary": "   Under organization subtab in Matter tab, the comments added are not saved on clicking the Main save button ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 2
        },
        {
          "key": "ELM-26989",
          "summary": "   Stack trace is displayed on clicking Save button for Organization and People  creation ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-26988",
          "summary": "   Stack Trace is displayed after updating the Matter Type details and clicking the Save button ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-26668",
          "summary": "   Tree view functionality not working after jquery upgrade ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        }
      ]
    },
    "Titans": {
      "total": 11,
      "tadComplete": 0,
      "tsComplete": 6,
      "bothComplete": 0,
      "tadPct": 0.0,
      "tsPct": 54.54545454545454,
      "issues": [
        {
          "key": "ELM-27635",
          "summary": "   SummaryTables CDC has been failed ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27740",
          "summary": "   Transaction pausing  period is set to 300 ms (0.3s) . ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27358",
          "summary": "   PERF|STD & SPEND INVOICE REPORTS|Report loading time exceeds defined SLA (> 10 seconds) 1 month data range ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-20719",
          "summary": "      Prepare Data comparison scripts for Passport fact tables and log records  ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 4
        },
        {
          "key": "ELM-20716",
          "summary": "Prepare Data comparison scripts for Passport dimension tables and log records",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 1
        },
        {
          "key": "ELM-22140",
          "summary": "Prepare Data comparison scripts for Passport bridge tables and log records",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 2
        },
        {
          "key": "ELM-24576",
          "summary": "Build data control report to show data mismatches ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-20715",
          "summary": "Prepare Data comparison scripts for Passport lookup tables and log records",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 1
        },
        {
          "key": "ELM-22141",
          "summary": "Prepare Data comparison scripts for Passport custom tables and log records",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 1
        },
        {
          "key": "ELM-20722",
          "summary": "ARD Passport and Oasis CDC Control report & Monitor",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-26450",
          "summary": "   PERF|Control REPORTS|ROW COUNT TREND ANALYSIS loading time exceeds defined SLA (> 10 seconds) ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        }
      ]
    },
    "PP Spartans": {
      "total": 12,
      "tadComplete": 0,
      "tsComplete": 4,
      "bothComplete": 0,
      "tadPct": 0.0,
      "tsPct": 33.33333333333333,
      "issues": [
        {
          "key": "ELM-25294",
          "summary": "SonarQube Framework : Security - Download Header Flaws - Cookie without secure flag L208 Excel view",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 4
        },
        {
          "key": "ELM-25802",
          "summary": "   SonarQube Framework : (Java) Security - Cookie without the secure flag - BaseMultiActionController  L399 and L401",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 2
        },
        {
          "key": "ELM-14061",
          "summary": "UI changes in passport - Mission 2",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-14021",
          "summary": "Billing | Billing Rule - UI Changes",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-25794",
          "summary": "   SonarQube Framework : Security High - Potential SQL/HQL Injection (Hibernate) Vulnerabilities - Base instance DAO ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 1
        },
        {
          "key": "ELM-27542",
          "summary": "   Multiple validation messages are displayed when the user creates duplicates under Users list page ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27540",
          "summary": "   Error message not populated on the value field when we do Initialize to new Version ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27123",
          "summary": "   Add Tenant details for Error logger ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 2
        },
        {
          "key": "ELM-17992",
          "summary": "PRB0056211 - Passport Feign Client - network connectivity error when calling the Legal Hold HTTP endpoint, close all idle connections",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-25793",
          "summary": "   SonarQube Framework : Security High - Potential SQL/HQL Injection (Hibernate) Vulnerabilities - Hibernate search DAO ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 1
        },
        {
          "key": "ELM-14102",
          "summary": "NFR | Sonar scan severity report fixes - Passport LE adaptor",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-13936",
          "summary": "LE Co-Ordinator UI changes",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        }
      ]
    },
    "PP Supernovas": {
      "total": 22,
      "tadComplete": 1,
      "tsComplete": 1,
      "bothComplete": 0,
      "tadPct": 4.545454545454546,
      "tsPct": 4.545454545454546,
      "issues": [
        {
          "key": "ELM-27537",
          "summary": "            Hartford SPOL - When there are more items in the queue for the PABU change and the scheduled job is executed, all matter get fails    ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-27535",
          "summary": "         Edoc 2.1.0 OAuth- adding File more than 5mb is not listing under documents tab   ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27551",
          "summary": "SPOL Hartford-Getting 500 Internal Server Error while rename Doc & Folder in Main Doc Tab ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27534",
          "summary": "         Edoc 2.1.0- Folder is not displaying under document and email tab   ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27418",
          "summary": "   eDocs - Oauth2 - Validation Error does not Displayed for Document Management Server URL value, in Admin Screen ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27407",
          "summary": "      In the large file Upload, we are getting \"location stack trace\" in the last transaction.  ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27093",
          "summary": "   Lowes - Getting 500 Error while Quick Search in GDL tab ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27089",
          "summary": "   Getting \" Your Request cannot be processed\" Error Message while navigate to Email Tab in Office Companion - Lowes ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27042",
          "summary": "   Edoc - Some filters were not working UI ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-24693",
          "summary": "   iManage 4.0.0 -Quick Search is Not Working in GDL - All Documents Tab ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-23159",
          "summary": "[PP 25.1] [EDOCS 2.1.0] - Adding Email in the Nested Level Through Office Companion",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-22477",
          "summary": "[iManage] - BW - Email Threading",
          "type": "Bug",
          "status": "Closed",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 3
        },
        {
          "key": "ELM-12138",
          "summary": "[work card] Raymond James: Intelligent Filing - JR - Part 4",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 4
        },
        {
          "key": "ELM-22858",
          "summary": "[Lowe's] [2.1.0] [eDocs] [OAuth2] - Passport UI - Full CRUD Operations with OAuth - Emails",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-22577",
          "summary": "TO BE DELETED [Lowe's] [Basic Auth --> OAuth] - Regression Testing for OAuth and Kong Gateway Integration",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-17617",
          "summary": "[Lowe's] Passport Connectors - Ability to support OAuth2 from eDOCS connector when connecting to eDOCS",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-22189",
          "summary": "TO BE DELETED [Lowe's] [Basic Auth -> OAuth] OAuth2 Token Management for KONG Gateway API",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-21375",
          "summary": "TO BE DELETED [Lowe's] [Basic Auth -> OAuth] eDOCS Server Setup for OAuth2 Integration",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-21374",
          "summary": "TO BE DELETED [Lowe's] [Basic Auth -> OAuth] Installation and configuration of Kong API GW for communication with eDOCS",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-22568",
          "summary": "TO BE DELETED [Lowe's] [Basic Auth --> OAuth] - Admin Changes - Mapper for Document Operations",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-22574",
          "summary": "TO BE DELETED [Lowe's] [Basic Auth --> OAuth] - Kong Gateway and eDOCS Integration",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-22576",
          "summary": "TO BE DELETED [Lowe's] [Basic Auth --> OAuth] - OAuth Token Generation and Validation",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        }
      ]
    },
    "PP Pioneers": {
      "total": 7,
      "tadComplete": 0,
      "tsComplete": 1,
      "bothComplete": 0,
      "tadPct": 0.0,
      "tsPct": 14.285714285714285,
      "issues": [
        {
          "key": "ELM-25288",
          "summary": "   SonarQube Framework : Security Medium- Unencrypted Socket ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-11595",
          "summary": "[Dependency Card] [Work] Rest API - Remove the JSession ID from parameter for Authentication",
          "type": "Story",
          "status": "Re-finement",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-26286",
          "summary": "            CP API automation for EDS Scheduler   ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-22377",
          "summary": "Tunnel optimization work",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-25274",
          "summary": "   SonarQube Framework : Security High -  XML parsing vulnerable to XXE (DocumentBuilder) Vulnerabilities  ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-26311",
          "summary": "   CP API automation for In-Between-Time 2024 ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-25974",
          "summary": "   CP Tech Debt API automation for Cert Issuer,LEDES validator and EDS Reports",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        }
      ]
    },
    "IDT": {
      "total": 1,
      "tadComplete": 0,
      "tsComplete": 0,
      "bothComplete": 0,
      "tadPct": 0.0,
      "tsPct": 0.0,
      "issues": [
        {
          "key": "ELM-1521",
          "summary": "Provision of D1 environment",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 5
        }
      ]
    },
    "PP Platform Maintenance": {
      "total": 18,
      "tadComplete": 0,
      "tsComplete": 1,
      "bothComplete": 0,
      "tadPct": 0.0,
      "tsPct": 5.555555555555555,
      "issues": [
        {
          "key": "ELM-25301",
          "summary": "   SonarQube Galileo : Security High Vulnerabilities  -(XMLReader) is vulnerable to XML External Entity attacks",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-25291",
          "summary": "SonarQube Framework : Security Medium- XSS Vulnerabilities in timeout and write JSONResponse Methods",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-25275",
          "summary": "   SonarQube Framework : Security High -  HibernateSearchDAO Vulnerability in Readobject",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 1
        },
        {
          "key": "ELM-25303",
          "summary": "   SonarQube Framework : Security Low Vulnerabilities ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-24031",
          "summary": "[High] Apache Avro Upgrade 1.11.3 to 1.12.0 - Windows and Container Passport 24.2.1",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 2
        },
        {
          "key": "ELM-24038",
          "summary": "[Medium] Apache Tomcat upgrade 9.0.91 to 9.0.96 Container ,Windows  in Passport 24.2.1 and Standalone after 24.2.1 ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 2
        },
        {
          "key": "ELM-5992",
          "summary": "Given a new invoice is created and submitted when appeal is made and from CP appeal is processed this is landing in error manager Train Fix",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-5433",
          "summary": "Given user tries to Approve /reject the invoice simultaneously in two tabs where user opens first tab and approves/rejects in second tab this should provide an UI Validation message and should not go to the error manager",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-25271",
          "summary": "   SonarQube Framework : Security High - (Java) Classes should not be loaded dynamically ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-24271",
          "summary": "Eng. Analysis-HCA-HCA Invoice - Adjusting multiple line items on an invoice jumps user to header instead of next line item Train Fix",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-24037",
          "summary": "[Medium] Protobuf-java upgrade 3.21.10 to Protobuf-java 3.25.5  in Passport 24.2.1",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 3
        },
        {
          "key": "ELM-24036",
          "summary": "[Medium] Bouncy Castle\t Upgrade 1.76 to 1.79  in Passport 24.2.1",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-24035",
          "summary": "[Medium] Apache FOP  Upgrade 2.7 to 2.10  in Passport 24.2.1",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 3
        },
        {
          "key": "ELM-24034",
          "summary": "[High] Dnsjava  Upgrade 2.0.8 jar dependency removal - Passport 24.2.1",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-25815",
          "summary": "    Apache Tomcat upgrade 9.0.96 to 9.0.97 Container ,Windows  24.2 ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-25800",
          "summary": "   Library Upgrade  xstream 1.4.20 to 1.4.21 ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-11404",
          "summary": "[Library Upgrade] [Work Card] - Apache Groovy 2.4.14 to 2.4.21 Windows and Container",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 3
        },
        {
          "key": "ELM-25276",
          "summary": "    SonarQube Framework : Security High -  (Java) Security - Potential JDBC Injection (Spring JDBC) ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        }
      ]
    },
    "PP MSM": {
      "total": 1,
      "tadComplete": 0,
      "tsComplete": 0,
      "bothComplete": 0,
      "tadPct": 0.0,
      "tsPct": 0.0,
      "issues": [
        {
          "key": "ELM-2350",
          "summary": "Train merge - Bulk upload Active TK update existing sheet: ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        }
      ]
    }
  }
};