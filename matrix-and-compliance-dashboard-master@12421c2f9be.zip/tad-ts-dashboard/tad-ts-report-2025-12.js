window.reportData = {
  "dateRange": "2025-12-01 to 2025-12-31",
  "generated": "2026-01-08 08:45:28",
  "summary": {
    "total": 348,
    "tadComplete": 66,
    "tsComplete": 83,
    "bothComplete": 32,
    "missingTad": 282,
    "missingTs": 265,
    "tadPct": 18.96551724137931,
    "tsPct": 23.850574712643677,
    "bothPct": 9.195402298850574,
    "missingTadPct": 81.03448275862068,
    "missingTsPct": 76.14942528735632
  },
  "teams": {
    "PP Pioneers": {
      "total": 25,
      "tadComplete": 15,
      "tsComplete": 5,
      "bothComplete": 3,
      "tadPct": 60.0,
      "tsPct": 20.0,
      "issues": [
        {
          "key": "ELM-37909",
          "summary": "ePacket Validation Service: X.509 Certificate Authentication",
          "type": "Story",
          "status": "Closed",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 8
        },
        {
          "key": "ELM-37913",
          "summary": "ePacket Validation Service: Core Resilience4j Integration",
          "type": "Story",
          "status": "Closed",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 6
        },
        {
          "key": "ELM-32616",
          "summary": "TEC-434924- Nationwide-20.2-User and Scheduled Job Conflict",
          "type": "Bug",
          "status": "New",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-37875",
          "summary": "Incorrect crediting of firms with expense-only billing lines in CP usage feed",
          "type": "Bug",
          "status": "Closed",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 3
        },
        {
          "key": "ELM-39253",
          "summary": "CP - Cookie Management/Consent",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39642",
          "summary": "Backport OC 1.11 (GA) - Enhance Office Companion Resilience with Retry Logic",
          "type": "Story",
          "status": "Refined",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 3
        },
        {
          "key": "ELM-39643",
          "summary": "Backport to OC 1.11 (GA) - Graceful Handling of Encryption Failures in Restricted Environments \u2013 Office Companion",
          "type": "Story",
          "status": "Refined",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 2
        },
        {
          "key": "ELM-38917",
          "summary": "Backport OC 1.11 (HIG) - Enhance Office Companion Resilience with Retry Logic - Office Companion (HIG)",
          "type": "Story",
          "status": "Refined",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 2
        },
        {
          "key": "ELM-39472",
          "summary": "ePacket Validation Service: Create Invalid Description Validation rules",
          "type": "Story",
          "status": "Closed",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 4
        },
        {
          "key": "ELM-37926",
          "summary": "Backport to OC 1.11 (HIG) - Graceful Handling of Encryption Failures in Restricted Environments \u2013 Office Companion (HIG)",
          "type": "Story",
          "status": "Refined",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 2
        },
        {
          "key": "ELM-36252",
          "summary": "Enhance Office Companion Resilience with Retry Logic",
          "type": "Story",
          "status": "Closed",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 9
        },
        {
          "key": "ELM-37950",
          "summary": "Enhance Office Companion Resilience with Retry Logic - UI changes",
          "type": "Story",
          "status": "Closed",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 10
        },
        {
          "key": "ELM-36251",
          "summary": "Graceful Handling of Encryption Failures in Restricted Environments \u2013 Office Companion",
          "type": "Story",
          "status": "Closed",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 14
        },
        {
          "key": "ELM-39301",
          "summary": "Backport - Rest API Guardrails - HCA - 22.2",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-31156",
          "summary": "   INC3088510 - PRB0057401 Improve guard-rails and concurrency for rest requests ",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-39300",
          "summary": "Backport - Rest API Guardrails - DHL- 23.2.9",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39299",
          "summary": "Backport - Rest API Guardrails - Sasol - 22.1",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-3147",
          "summary": "Security Object Changes Causing Performance Issues When Done During The Day",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-33421",
          "summary": "TEC-434415 -Eng Analysis Office Companion - DHL -  OC Shut down unexpectedly on multiple occasions",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-43",
          "summary": "ePacket Validation Service: GUI for ruleset/client actions & Rules edit",
          "type": "Story",
          "status": "Closed",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 6
        },
        {
          "key": "ELM-34949",
          "summary": "ePacket Validation Service: Implement Client Rulesets Management for EVS",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 6
        },
        {
          "key": "ELM-37133",
          "summary": "ePacket Validation Service: Convert invoice parcel files to L2K format - header nodes",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 3
        },
        {
          "key": "ELM-64",
          "summary": "ePacket Validation Service: Create Date rules",
          "type": "Story",
          "status": "Closed",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 6
        },
        {
          "key": "ELM-38361",
          "summary": "ePacket Validation Service: Validate LEDES screen/link EVS",
          "type": "Story",
          "status": "Closed",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 5
        },
        {
          "key": "ELM-39473",
          "summary": "ePacket Validation Service: Invalid Description Validation",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        }
      ]
    },
    "PP Genesis": {
      "total": 61,
      "tadComplete": 10,
      "tsComplete": 10,
      "bothComplete": 5,
      "tadPct": 16.39344262295082,
      "tsPct": 16.39344262295082,
      "issues": [
        {
          "key": "ELM-37833",
          "summary": "Direct Document Upload from Office Companion to SPOL",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-37807",
          "summary": "Email Thread count logic validation for Auto Threading",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-38482",
          "summary": "eDocs - Handle the duplicates in Migration Utility",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-40042",
          "summary": "Archive and Purge Implementation in iManage",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-33550",
          "summary": "TEC-420079 - Eng Analysis - Undo Checkout failure - Hartford wants is there any way to undo checkout by IT team",
          "type": "Bug",
          "status": "Analyze",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39206",
          "summary": "Duplicate emails getting uploaded when email is present in Different folders and has different time",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-29165",
          "summary": " TEC-426265-   Zurich : Bad Query plan for SQL DB ",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-29167",
          "summary": "   Zurich : alf_node_properties and alf_node has more record ",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-33626",
          "summary": "TEC-426190 - Eng Analysis - Alfresco Search Service 2.8.0.1 didn't give proper results",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-33634",
          "summary": "TEC-426188 - Eng Analysis - Content search is not operational in Alfresco",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-33638",
          "summary": "TEC-426189 - Eng Analysis - We are frequently encountering Solr connection errors when searching for documents",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39980",
          "summary": "Not able to upload document to a matter after renaming it.",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-37548",
          "summary": "IManage  -LEDES File Not Displayed in Invoice Document Tab After Upload 98BI file through CP",
          "type": "Bug",
          "status": "Analyze",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39973",
          "summary": "OC 1.11 - JR GA HCA - Able to reproduce a javaScript Error in 1.11.13001 Build",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-34061",
          "summary": "HIG: Office Companion - Consolidated Bundle to Support the Encryption and Large File Support",
          "type": "Story",
          "status": "Closed",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 5
        },
        {
          "key": "ELM-39976",
          "summary": "Apply Folder security for existing folders",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39974",
          "summary": "eDocs 2.8.0 - PABU Movement Tracker Page Validations",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39747",
          "summary": "Lowes - Urgent Patch - Async Issue",
          "type": "Bug",
          "status": "Closed",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 4
        },
        {
          "key": "ELM-34157",
          "summary": "eDocs 2.4.0 - OC 1.11.11991- Large file support Download\\Upload",
          "type": "Story",
          "status": "Closed",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 17
        },
        {
          "key": "ELM-39785",
          "summary": "iManage Async Issue",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39786",
          "summary": "SPOL Async Issue",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39570",
          "summary": "SPOL 4.0.5 - Temp Storage cleanup for HugeFile Operation",
          "type": "Story",
          "status": "Refined",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 4
        },
        {
          "key": "ELM-39571",
          "summary": "SPOL - Cleanup the Failed Large File uploads ",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-36727",
          "summary": "eDocs 2.8.0 - Automate Workspace Creation and Security Application for Existing Matters in eDOCS",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-29108",
          "summary": "    Legal Document Preview  - Search and Highlight Text ",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39417",
          "summary": "Framework- Internal - Docs not visible in matters - PP 26.1",
          "type": "Bug",
          "status": "New",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-39572",
          "summary": "eDocs 2.9.0 - Temp Storage cleanup for HugeFile Operation",
          "type": "Story",
          "status": "New",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-29101",
          "summary": "    Legal Document Preview - Multi-format Support ",
          "type": "Story",
          "status": "Analyze",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-38866",
          "summary": "eDoc Bundle change 2.7.3 -Duplicate Workspace Created in eDocs Upon Invoice Submission and Matter",
          "type": "Bug",
          "status": "Pre-Refinement",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-26097",
          "summary": "   TEC-378301-Engg Analysis - Hartford - Parsing Exception on DocManagerCommonService ",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-39507",
          "summary": "eDocs - Archive and Purge for all Entities",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-38923",
          "summary": " iManage - GDL Tab Displays Error Message Despite Successfully Loading Data",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-38696",
          "summary": "eDoc-Unable to Check In Document with Major/Minor Version After Rename document.",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-26104",
          "summary": "   TEC-377545-Engg Analysis: User encounters error when accessing Document List Page ",
          "type": "Bug",
          "status": "New",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-26611",
          "summary": "   [Hartford] [SPOL] [OC] [TEC-379913] - HIG User consistently looses quick file options ",
          "type": "Bug",
          "status": "Analyze",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-33628",
          "summary": "TEC-428259 - Eng Analysis - LoadedClassCount Behavior and Connector Module Optimization",
          "type": "Bug",
          "status": "Pre-Refinement",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-29106",
          "summary": "   Legal Document Preview  - Quick Rendering ",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-30974",
          "summary": "eDocs - Enable PABU-level Security Configuration as an Admin-Only Checkbox ",
          "type": "Story",
          "status": "Analyze",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-29155",
          "summary": "   Legal Document Preview - Document Preview for Download   ",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-29110",
          "summary": "   Legal Document Preview - Page Thumbnails  ",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-38188",
          "summary": "iManage - GDL Tab \u2013 'Recent Documents' and 'All Documents' Not Listing by Default",
          "type": "Bug",
          "status": "Analyze",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-29142",
          "summary": "   Legal Document Preview  - Zoom & Fit options ",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-16609",
          "summary": "JR - Large File Upload - REST API Document/Email upload",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39506",
          "summary": "SPOL - Archive and Purge for All Entities",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39338",
          "summary": "ICD 23.2 + Office Companion 1.13.13005 : Not able to update Event Name and Event Sub Category",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-26631",
          "summary": "[Hartford] [SPOL] [Connectors] [TEC-405259] - Bad gateway error in Passport when trying to rename a document. ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39573",
          "summary": "eDocs 2.9.0 - Cleanup the Failed Large File uploads ",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-33548",
          "summary": "TEC-417567 -Eng Analysis - Hartford \u2013 User receives 520 error",
          "type": "Bug",
          "status": "Closed",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-26630",
          "summary": "[Hartford] [SPOL] [Connectors] [TEC-408657] - BRCC Document Failed with [500 Internal Server Error] during [POST]  ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 3
        },
        {
          "key": "ELM-26614",
          "summary": "[Hartford] [SPOL] [Connectors] [TEC-392077] - 500 error when attempting to drag and Drop emails or files to OC ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-25252",
          "summary": "   [SPOL 3.0.XX] - TEC-394535 - HIG Performance - Users are getting 502 bad gateway errors ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-38048",
          "summary": "eDocs : Passport misinterprets HTTP 206 Partial Content response from eDocs API as 'Invalid custom attribute mapping' error for all scenarios",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-33619",
          "summary": "eDocs: CP - Vendor Based Organization user having Multiple Organization association support",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-27044",
          "summary": " SPOL - Logging email subjects in Oasis ",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-33631",
          "summary": "TEC-431141 - Eng Analysis - for TEC-430999: PABU has been modified for this matter, Document movement is currently in progress. Please retry this operation after the document movement is completed",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-29775",
          "summary": "   INC3046726 - PRB0057175 Ensure that all critical dependencies, such as the Docservice Version, are cross-referenced in both the Release Notes and the Installation Guide ",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-33549",
          "summary": "TEC-423366 -Eng Analysis - Hartford: Duplicate documents and Error received when clicking on the document tab in Passport",
          "type": "Bug",
          "status": "Closed",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 7
        },
        {
          "key": "ELM-39444",
          "summary": "[Tech Debt] Doc Connectors: Custom scripts to support Connector specific UI handling",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39000",
          "summary": "eDocs Migration Utility - Failure Message and count mismatch on failed records during Migration",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27043",
          "summary": "   eDOCS - Logging email subjects in Oasis ",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-38194",
          "summary": "eDoc - OC - After adding the Task and Event user not able to edit it.",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        }
      ]
    },
    "Oasis Allstars": {
      "total": 11,
      "tadComplete": 4,
      "tsComplete": 3,
      "bothComplete": 3,
      "tadPct": 36.36363636363637,
      "tsPct": 27.27272727272727,
      "issues": [
        {
          "key": "ELM-37553",
          "summary": "Doc service- eDocs - Folder security alignment with document-level security",
          "type": "Story",
          "status": "To Verify",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 6
        },
        {
          "key": "ELM-36202",
          "summary": "Creating Public matter as NON SSO User with SSO checkbox NOT checked is displaying private in iManage",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-36193",
          "summary": "Creating a Private matter without mapping is displaying empty in user/group section on iManage",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-40017",
          "summary": "eDocs - Doc Service -Missing Document Visibility in Passport and OC while change the PIC ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 4
        },
        {
          "key": "ELM-38832",
          "summary": "Doc Service Code Merge to Dev Branch and Regression Testing",
          "type": "Story",
          "status": "To Verify",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-37644",
          "summary": "Internal Server exception while renaming the document.",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39975",
          "summary": "TD: Doc-Service add co-pilot instructions",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-37143",
          "summary": "Benchmark - Remediate Medium Vulnerabilities in json-smart, logback, protobuf-java",
          "type": "Story",
          "status": "Code Complete",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-38996",
          "summary": "eDocs OC _ Lowes_ Quick Search and Filters Not Working as Expected.",
          "type": "Bug",
          "status": "To Verify",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 5
        },
        {
          "key": "ELM-39293",
          "summary": "Doc Service- eDocs : Group Mapping : On Changing Matter PABU on Passport, security details are not updated on eDocs Info Center",
          "type": "Bug",
          "status": "Analyze",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39674",
          "summary": "Cleanup on Duplicate Workspace for TO-10719",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        }
      ]
    },
    "Unknown Team": {
      "total": 66,
      "tadComplete": 1,
      "tsComplete": 6,
      "bothComplete": 1,
      "tadPct": 1.5151515151515151,
      "tsPct": 9.090909090909092,
      "issues": [
        {
          "key": "ELM-38373",
          "summary": "[TO-9825] - UBS- GA patch - cumulative fix for optimize purge process",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 4
        },
        {
          "key": "ELM-33666",
          "summary": "TEC-427478 - Eng Analysis - Cluster configurations breaking search indicies",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-22355",
          "summary": "[TEC-394769] - LSR - PABU changes impact",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-33228",
          "summary": "[TEC-408260] - Train Fix - Incorrect weekly scheduled job's next occurrence",
          "type": "Bug",
          "status": "New",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 2
        },
        {
          "key": "ELM-20646",
          "summary": "PTASK0031728 - PRB0056413 Determine if Hartford needs a Custom Certificate for stability's sake and if so, implement it.",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-20754",
          "summary": "PRB0056259 - Revisit all XMS/XMX settings for hosted environments ",
          "type": "Story",
          "status": "Resolved",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-25131",
          "summary": "   PRB0056756 - PTASK0032478 validate CDC after deployment window ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-31151",
          "summary": "   INC3091046 - PRB0057424 - PTASK0033826 Upgrade Java to the latest compatible version to Passport 20.2.5 ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-31154",
          "summary": "   INC3088510 - PRB0057401 Do not run intensive REST calls without search parameters(filters) during business hours. Look into RFI query options. ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-31157",
          "summary": "   INC3088510 - PRB0057401 Update process to note on the TEC for an incident why a heapdump was not acquired if the incident was related to Java heap exhaustion. ",
          "type": "Story",
          "status": "Resolved",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-31952",
          "summary": "   INC3092650 -  PRB0057433 Implement Monitoring to alert or notify when the memory usage reaches a critical threshold ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-34537",
          "summary": "INC3163235 - PRB0057913 Update the monitoring tool to improve its timeout handling and limit the number of concurrent connections it can attempt to a Passport system.",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-32482",
          "summary": "   PRB0057742 - Deploy the updated DWH images to all the clients ",
          "type": "Story",
          "status": "Resolved",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-20241",
          "summary": "RCAS0042787 - PRB0056368 Update QA process related to groovy code that could be impacting global settings/non-local variables",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-18386",
          "summary": "PRB0056288 - RCAS0041144 Implement connections closure to avoid resource leakage.",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-25386",
          "summary": "   PRB0056288 - PTASK0031443 Implement robust exception handling for all API requests. ",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-21736",
          "summary": "PRB0056457 - RCAS0045110 Follow the best practices of customization, enable the validators unless it is instructed in the document to disable it.",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-25387",
          "summary": "   PRB0056288 - PTASK0031447 Implement connections closure to avoid resource leakage. ",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-18385",
          "summary": "PRB0056288 -RCAS0041143 Implement read and connection timeout settings from integration config for all API calls.",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-18388",
          "summary": "PRB0056288 -RCAS0041146 Implement retry mechanism to enhance service availability.",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-20240",
          "summary": "RCAS0042786 - PRB0056368 Update impact analysis and code review strategy for all groovy code that could be impacting global settings/non-local variables ",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-23713",
          "summary": "PRB0056625 - Analysis and Improvement of the OnBeforeCreate and OnCreate events for the TimeEntry object ",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-23730",
          "summary": "PRB0056625 - Addition of indexes to the Time Entry table to improve performance ",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-23731",
          "summary": "PRB0056625 - Update customer project process to include the development of performance requirements, development/analysis, and testing ",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-25384",
          "summary": "   PRB0056288 - PTASK0031444 Implement read and connection timeout settings from integration config for all API calls. ",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-25385",
          "summary": "   PRB0056288 - PTASK0031446 Implement retry mechanism to enhance service availability. ",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-29350",
          "summary": "   INC3049071 - PRB0057190 Create Patch to optimize Vendor Sync job by reducing repeated queries, updates. Indexing the fields and batch processing should also be considered ",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-35437",
          "summary": "INC3195753 - PRB0058055 Create Performance Testing Scenarios",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-35781",
          "summary": "INC3215978 - PRB0058222 Fix VendorSyncImpl.groovy getDelta() Method Logic",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-35782",
          "summary": "INC3215978 - PRB0058222 Redesign Vendor Sync Architecture for Memory Efficiency",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-35787",
          "summary": "INC3215978 - PRB0058222 Create Performance Testing Scenarios for Vendor Sync",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39988",
          "summary": "Passport OC- Multiple filters in the Matter Summary Document section are not functioning correctly; some have incorrect UX/UI",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39997",
          "summary": "Passport OC- Received Date filter has incorrect UX/UI on My Invoices page.",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-35784",
          "summary": "INC3215978 - PRB0058222 Implement Configuration Validation and Monitoring",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-39979",
          "summary": "Passport OC- Filters for Matter Type, Matter Status, and Primary Internal Contact (PIC) are not functioning correctly on the Matter List page",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-39972",
          "summary": "Passport OC- Saved view filter in Matter List page does not retain filtered results after navigation; displays default matter list instead",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39978",
          "summary": "Passport OC- Filters for Matter Type, Matter Status, and Primary Internal Contact (PIC) are not functioning correctly on the Matter List page",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39977",
          "summary": "Passport OC- Filters for Matter Type, Matter Status, and Primary Internal Contact (PIC) are not functioning correctly on the Matter List page",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-38153",
          "summary": "INC3134038 - PRB0057737 Create, review and apply new policy to prevent blob container storage deletion",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-26670",
          "summary": "   PRB0056727 - PRB0056727 Implement purge/clean-up scripts for the Manulife environments. ",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-26695",
          "summary": "    PRB0056837 - Setup and alert when the socket timeout error occurs in the SDK pod log  ",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-37417",
          "summary": "INC3246624 - PRB0058485 Add integrity validation for the storage system to monitor I/O health.",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-17597",
          "summary": "Use the Deployment Parameter verification to check which other clients may be at risk of experiencing this issue.",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-35798",
          "summary": "PRB0058325 Review and optimize node pool resource allocation",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-25795",
          "summary": "   PRB0056837 - PTASK0032579 Create an SOP to re-execute the SDK pipeline when alerted and confirm that errors are not present in the SDK pod log ",
          "type": "Story",
          "status": "Resolved",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-29203",
          "summary": "   INC3056915 - PRB0057228 Review startup procedures for Cognos in Windows environments.  IBMs stance is to utilize the Cognos UI for proper startup. ",
          "type": "Story",
          "status": "Resolved",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-31211",
          "summary": "   INC3085566 - PRB0057380 Update or create any SOP needed based on the re distribution workload ",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-32483",
          "summary": "   PRB0057742 - IPM/GBS to set a minimum memory request(~8GB) in the deployments so that the PODs are better distributed in the node pool ",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-32637",
          "summary": "PRB0057811 - Preventing pods from running on nodes that do not have sufficient resources to properly execute the pods is critical for proper pod execution",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-35765",
          "summary": "INC3209064 - PRB0058172 Create automated backup/restore procedures for emergency scenarios",
          "type": "Story",
          "status": "In Progress",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-35767",
          "summary": "INC3209064 - PRB0058172 Update disaster recovery procedures to include Jackrabbit index scenarios",
          "type": "Story",
          "status": "Resolved",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39955",
          "summary": "[TO-9825] - UBS- GA patch - fix for purge job performance",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-12164",
          "summary": "Remediation of databases marked idle for more than 30 days",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39930",
          "summary": "CLONE - Remediation of databases marked idle for more than 30 days",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-35451",
          "summary": "INC3206316 - PRB0058147 Azure AKS Node Stability \u2013 For AKS node crash",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-36163",
          "summary": "An adversary can upload multi-extension files onto the server",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-34494",
          "summary": "LBA MySQL workbench Query",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-35820",
          "summary": "The expected validation message is not displayed when an SSO user is prevented from deleting the document",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-35819",
          "summary": "SSO User Unable to Check Out Document When DM Subject Identifier Type is \"User Email Address\"  in DM Server configuration",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39562",
          "summary": "AFA Module \u2013 Williams: Rating Icon Missing on Organization List Page for Super Users Without Cognos Permissions",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-35764",
          "summary": "INC3209064 - PRB0058172 Implement enhanced monitoring for Jackrabbit indexing status",
          "type": "Story",
          "status": "Resolved",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-23347",
          "summary": "PRB0056618 - PTASK0032154 -  ClearEntityEventHistory is setup to run at the same time as ProcessHibernate job. They both take a lot of resources. Schedule them at different times and mark them as incompatible",
          "type": "Story",
          "status": "Resolved",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-17848",
          "summary": "The code that checks for DWH status should be improved such that it does not run indefinitely",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-29667",
          "summary": "   Zurich : Purge Job read time out when deleting matters from Alfresco ",
          "type": "Bug",
          "status": "Pre-Refinement",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-35799",
          "summary": "PRB0058325 Implement memory usage alerting for Cognos node pools",
          "type": "Story",
          "status": "Resolved",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-38845",
          "summary": "INC3306442 - PRB0058901 DBA access will be fixed.",
          "type": "Story",
          "status": "Analyze",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        }
      ]
    },
    "PP Spartacles": {
      "total": 56,
      "tadComplete": 16,
      "tsComplete": 14,
      "bothComplete": 11,
      "tadPct": 28.57142857142857,
      "tsPct": 25.0,
      "issues": [
        {
          "key": "ELM-28682",
          "summary": "[TEC-421339] - Train Fix - Fix for removed person selectable in invite/assignee",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-38446",
          "summary": "[TEC-362955]-Train fix- While purging a matter facing delete conflict error for MESSRELAT_LINE_ITEMS",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39116",
          "summary": "[TO-10356] - Engineering Analysis : Archive Job SQL Parameter Limit Fix",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39954",
          "summary": "ICD Module : Conflict Check failing due to LazyInitialization exception on InsCriteriaBuilders",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-35884",
          "summary": "[TO-2857] - Train Fix: Panel Counsel and RV Query - Argo - 22.2.1 - Pending Approval Validator for Invoices and Client Matters",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-28154",
          "summary": "   The Archive and Purge Criteria page under Application Settings should include an \"Active\" checkbox for each filter, allowing users to enable or disable filters as needed ",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39938",
          "summary": "[TO-11078] - Engineering Analysis- Missing Rating Icon When Evaluating Organizations",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39949",
          "summary": "Invoice count Mismatch - Organization -> Financials - >Mismatch in the original invoice count for an organization.",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-33719",
          "summary": "Budget rule for forecast type budget",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39953",
          "summary": "[TO-11301] Allocation Module: Invoice Allocation Decimal Correction error when net total mismatches",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-33657",
          "summary": "[TEC-413861] - Displaying the 'Timekeeper Diverse Calculation Update Command' error.",
          "type": "Bug",
          "status": "Refined",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 2
        },
        {
          "key": "ELM-28362",
          "summary": "[TEC-414467] - Engg Analysis: UBS - Single Auto-Complete Control for Lookup sometimes not allowing you to Select ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 1
        },
        {
          "key": "ELM-39929",
          "summary": "[TO-10356] - Engineering Analysis : Archive Job Processing Records Partially",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-38627",
          "summary": "[CDE] - Document Preview",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-28462",
          "summary": "TEC-343945 - Long term fix - Check and enforce the base amount on Money field ",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-28456",
          "summary": "   Eng. Analysis: [TEC-364932] Issue with Access The emails document under matter in OC - Need to fix for more than 40K records ",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-28447",
          "summary": " [TEC-404449] - [01 PPOD ]Eng Analysis Raymond James | TT-40460 | Items 197082: Automation of Acknowledgement Letters: Stack Trace error | Document Assembly Template ",
          "type": "Bug",
          "status": "New",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 2
        },
        {
          "key": "ELM-24618",
          "summary": "Patch for INC2728180 / PRB0055821 / PTASK0030457 / [TEC-371090] [PP-22.2.0-GA1] Skip user security cache refresh when modifying Security Entities through Spreadsheet Loader        ",
          "type": "Story",
          "status": "Refined",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 3
        },
        {
          "key": "ELM-11633",
          "summary": "CSRF Pen Test - [Workcard] - Use UNIQUE_TOKEN for CSRF Protection",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39740",
          "summary": "INC3249378 - PRB0058496 [Passport][Tech Debt] [Refactor] - Security Cache - Change Filtering & Backporting fix",
          "type": "Story",
          "status": "Refined",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 2
        },
        {
          "key": "ELM-39496",
          "summary": "[Passport] [URP] - Analytics Onboarding - Auto-mapping Passport Super Role to EmbedFAST Tenant Owner",
          "type": "Story",
          "status": "Refined",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 2
        },
        {
          "key": "ELM-5558",
          "summary": "Correct Invoice Summary Values in Invoice List Exports (PDF & Excel)",
          "type": "Bug",
          "status": "Analyze",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-28493",
          "summary": "[CDE] [Pinnacles] - Search Criteria for Add Filters & Add Columns\u00a0 ",
          "type": "Story",
          "status": "Pre-Refinement",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-29109",
          "summary": "[CDE] [Spartans] - Related Invoices",
          "type": "Story",
          "status": "Pre-Refinement",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-24616",
          "summary": "Patch for INC2728180 / PRB0055821 / PTASK0030457 / [TEC-371090] [PP-21.2.2-GA5] Skip user security cache refresh when modifying Security Entities through Spreadsheet Loader    ",
          "type": "Story",
          "status": "Refined",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 3
        },
        {
          "key": "ELM-24614",
          "summary": "Patch for INC2728180 / PRB0055821 / PTASK0030457 / [TEC-371090] [PP-20.2.5-GA7] Skip user security cache refresh when modifying Security Entities through Spreadsheet Loader  ",
          "type": "Story",
          "status": "Refined",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 3
        },
        {
          "key": "ELM-39243",
          "summary": "[Pro Forma] - Create a new action and rule",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39242",
          "summary": "[Pro Forma] - Admin Configuration for Flexible Taxed Invoice Handling",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39548",
          "summary": "Config changes in Framework-V3UI project NOT to access the npmjs",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39136",
          "summary": "[Library Upgrades] - Upgrade of js-yaml Dependencies to 4.1.1",
          "type": "Story",
          "status": "Closed",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 4
        },
        {
          "key": "ELM-39012",
          "summary": "[Predictive Insights] [UFG] - Fix for Zero Prediction Matters Remaining in Pending Status",
          "type": "Bug",
          "status": "Closed",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 9
        },
        {
          "key": "ELM-13220",
          "summary": "[TEC-235662] Modify the authorization class to not flush the security flash when the changes does not related to security",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-22808",
          "summary": "[TEC-389154] Engg Analysis: Duke - Invoice Workflow Template is not updated on the Matter ",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-28458",
          "summary": "   Base Log Spelling Error ",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39559",
          "summary": "[CDE] - Bulk Re-assignment of Invoices in Review",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-33621",
          "summary": "[TEC-416723] - Eng Analysis - DWS | TT-40719, TT-40720, TT-40721 and TT-40722 | Remove External Comments field from JSP Pages",
          "type": "Bug",
          "status": "Closed",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 2
        },
        {
          "key": "ELM-30919",
          "summary": "[TEC-429087] - Eng. Analysis - Raymond James -20.1- Document Assembly not Refreshing Fields Due to Formatting ",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-28358",
          "summary": "[TEC-416803] - [04] Hartford - Date sorting not working in Dashboard ",
          "type": "Bug",
          "status": "New",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-39119",
          "summary": "[Security] [PEN TEST] - Implement Rate Limiting for Web Application for un-authenticated endpoints",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-39471",
          "summary": "Predictive Insights - Scores not listed for Matter Budget",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-28448",
          "summary": "[TEC-403916] [GA]- ICD Doesn't calculate with User time zones ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 13
        },
        {
          "key": "ELM-24617",
          "summary": "INC2728180 / PRB0055821 / PTASK0030457 / [TEC-371090] [PP-22.2.2-GA3] Skip user security cache refresh when modifying Security Entities through Spreadsheet Loader      ",
          "type": "Story",
          "status": "Closed",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 8
        },
        {
          "key": "ELM-38628",
          "summary": "[CDE] - Expanded Bulk Edit Options",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-28453",
          "summary": "[TEC-392386] - Citi - MatterBudgetChildFiscalPeriodWithinParentErrorValidator not working ",
          "type": "Bug",
          "status": "Analyze",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-31076",
          "summary": "   Menu icon in GREY color when menu dropdown is opened ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-31068",
          "summary": " Bootstrap -  In top framework the background color of Menubar is not displayed in white color ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-31111",
          "summary": "   Bootstrap-Alignment issues (aligned lower) in the dropdown text displayed on clicking APPS, MENU ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-31070",
          "summary": "   Bootstrap- Currency UI display issues ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-31073",
          "summary": "   Alignment issue in Favorite icon dropdown ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-31066",
          "summary": "   Bootstrap-When  hovered over the help icon the color is not changing to white ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-31065",
          "summary": "   Bootstrap-Matter & Spend title display is slightly aligned down  ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-31074",
          "summary": "         Blue bar displayed in APPS,MENU & HOME when clicked ENTER in keyboard   ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-31075",
          "summary": "   Search dropdown is moved towards the 3 dots in the Top Framework ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-31067",
          "summary": "   Bootstrap - Alert & its drop down -UI display issues ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-31069",
          "summary": "   Bootstrap -User Setting  UI display issues ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-33618",
          "summary": "[TEC-409957] - Eng Analysis for TEC-409794 -   Invisible Matter Description ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        }
      ]
    },
    "Passport Modernization": {
      "total": 1,
      "tadComplete": 0,
      "tsComplete": 0,
      "bothComplete": 0,
      "tadPct": 0.0,
      "tsPct": 0.0,
      "issues": [
        {
          "key": "ELM-2137",
          "summary": "Java version to be upgraded to LTS release ( 21.x ) (EDIT MPW: Java version to be analyzed for appropriate upgrade)",
          "type": "Story",
          "status": "Analyze",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        }
      ]
    },
    "Avengers": {
      "total": 14,
      "tadComplete": 10,
      "tsComplete": 6,
      "bothComplete": 6,
      "tadPct": 71.42857142857143,
      "tsPct": 42.857142857142854,
      "issues": [
        {
          "key": "ELM-33610",
          "summary": "TEC-413757 - Eng Analysis - Hartford: Documents not accessible after matter Pabu change",
          "type": "Bug",
          "status": "Closed",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 3
        },
        {
          "key": "ELM-39339",
          "summary": " [TO-9825] - UBS- GA patch to Dev- cumulative fix for optimize purge process",
          "type": "Bug",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-27482",
          "summary": "   FDIC - Add Narrative in OC - Defect",
          "type": "Bug",
          "status": "Closed",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 2
        },
        {
          "key": "ELM-33543",
          "summary": "TEC-407349 - Eng Analysis - unable to open documents in webdav when there is any special characters on matter name",
          "type": "Bug",
          "status": "Closed",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-39379",
          "summary": "Enable URL Encoding for Document Rename Operations Across Connectors",
          "type": "Bug",
          "status": "Closed",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-39384",
          "summary": "Implement Centralized Error Handling to Prevent Unclassified Server Errors",
          "type": "Bug",
          "status": "Closed",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-33613",
          "summary": "[TEC-424148] - Train Fix - Walgreens - Invoices are landing in Error Manager with NullPointerException",
          "type": "Bug",
          "status": "Closed",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 3
        },
        {
          "key": "ELM-30625",
          "summary": " [TEC-427381] - Investigate Country/State Lookup Missing Active Checkbox ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 7
        },
        {
          "key": "ELM-31571",
          "summary": "   TEC-421587 Trunk client Passport CP Tunnel disconnect  ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-33377",
          "summary": "TEC-421587 Engg Analysis Respin Auto restart workaround patch",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-33378",
          "summary": "TEC-432100 Engg Analysis  - Active Tunnel Transactions and not completing.",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-30769",
          "summary": "  [TEC-404595] - Train Fix - Fix for Average Case Closure Time by Business Unit Dashboard report ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 4
        },
        {
          "key": "ELM-31459",
          "summary": " [TEC-428358] - Train Fix- Unexpected Behavior When Saving Changes on Private Matters ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 6
        },
        {
          "key": "ELM-34085",
          "summary": "Train Fix:HCA-22.2-Increasing the LBACustomLBAField size",
          "type": "Bug",
          "status": "Closed",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 6
        }
      ]
    },
    "Guardians": {
      "total": 43,
      "tadComplete": 5,
      "tsComplete": 21,
      "bothComplete": 2,
      "tadPct": 11.627906976744185,
      "tsPct": 48.837209302325576,
      "issues": [
        {
          "key": "ELM-32641",
          "summary": "PRB0057811 - Deploy Cognos Audit in Apollo environment.",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39945",
          "summary": "Santander - Rate Benchmark Dashboard Setup",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-39946",
          "summary": "Williams - Rate Benchmark Dashboard Setup",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-33075",
          "summary": "TEC-426131 - CDC is failing after deploying the CDC container restart fix for DWH 19.2",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 4
        },
        {
          "key": "ELM-33047",
          "summary": "Engg Analysis-HCA-Table Extract CDC issue [workaround] ",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-33050",
          "summary": "TEC-434398 - Eng Analysis - CDC job takes 5 hrs after enabling Embedded Viz",
          "type": "Bug",
          "status": "Resolved",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 1
        },
        {
          "key": "ELM-39944",
          "summary": "Equitable - Rate Benchmark Dashboard Setup",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-39942",
          "summary": "Bridgewater - Rate Benchmark Dashboard Setup",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-39939",
          "summary": "ALAS - Rate Benchmark Dashboard Setup",
          "type": "Story",
          "status": "Analyze",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-39941",
          "summary": "Argo - Rate Benchmark Dashboard Setup",
          "type": "Story",
          "status": "Analyze",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-28507",
          "summary": " Centerpoint - Rate Benchmark Dashboard Setup ",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39943",
          "summary": "CenterPoint - Rate Benchmark Dashboard Setup",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-23864",
          "summary": "[01]HCA (PH0081) - Rate Benchmark Dashboard Setup",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-38219",
          "summary": "Implement Dashboard Events, Export Options, and Error Handling",
          "type": "Story",
          "status": "Analyze",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39686",
          "summary": " Update Python Scripts for Tableau Server v2025.x API Compatibility Update Publishing Components for v3.x API and test Environment Testing",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39651",
          "summary": "Python Scripts Update - Tableau Server v2025.x API Compatibility Update Tableau Server Authentication and API Endpoints",
          "type": "Story",
          "status": "Analyze",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-28936",
          "summary": "Summary tables CDC performance improvement for self hosted client.",
          "type": "Story",
          "status": "Refined",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-38221",
          "summary": "Refactor and update dashboard codebase for compatibility with upgraded Tableau ",
          "type": "Story",
          "status": "Refined",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-35925",
          "summary": "Permanent Fix Existing deprecated fields cause bulk load to fail 21.2 DWH Version",
          "type": "Story",
          "status": "Refined",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-33668",
          "summary": "TEC-431780 -Eng Analysis - Base Defect - Keyvault changes not reflecting/updating",
          "type": "Bug",
          "status": "Analyze",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39653",
          "summary": "Implement SSO Authentication and Secure Access Control",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39649",
          "summary": "Update Python Scripts for Tableau Server v2025.x API Compatibility",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-35648",
          "summary": "Cognos SDK Orchestration Pipeline Integration into Existing Cognos Image Versions",
          "type": "Story",
          "status": "Re-finement",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-17877",
          "summary": "Increase the memory request size in the deployment pipeline to allow Kubernetes to better distribute the Cognos pods in the node pools and set the Cognos maximum memory usage setting based on the Cognos memory consumption analysis",
          "type": "Story",
          "status": "Re-finement",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-35920",
          "summary": "Tableau Upgrade Rollback Implementation & Deployment",
          "type": "Story",
          "status": "Refined",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-18797",
          "summary": "PP Operability - Summary Table Load Performance Issue Fix on Full load in v21.2 ",
          "type": "Story",
          "status": "Pre-Refinement",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 1
        },
        {
          "key": "ELM-38220",
          "summary": "Functional Validation of Rate Management Dashboard",
          "type": "Story",
          "status": "Analyze",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-39654",
          "summary": "API Updates For Configuration functionality across all dashboards In LVD",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39650",
          "summary": "API Updates For Clear Filter functionality across all dashboards In LVD",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39647",
          "summary": "API Updates For Get Sheets List functionality across all dashboards In LVD",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-32639",
          "summary": "TEC-433097  - Permanent Fix  Existing deprecated fields cause bulk load to fail 23.2 DWH Version",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 1
        },
        {
          "key": "ELM-17878",
          "summary": "Increase the number of node pools to allow more containers to fully scale to their expected memory requirements.",
          "type": "Story",
          "status": "Re-finement",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-35991",
          "summary": "Cognos SDK Pipeline Rollout validation to support environment Level SDK Version Configuration for Cognos 11.2.4 IF4",
          "type": "Story",
          "status": "Closed",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 5
        },
        {
          "key": "ELM-38567",
          "summary": " FDL  T360 and Honeywell Cleanup for Qlik Replicate ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-32924",
          "summary": "Truncate of metadata is required for bulk load to function in 23.2 DWH Version",
          "type": "Bug",
          "status": "Analyze",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-28539",
          "summary": "Tableau Image Creation in Lower Non-Prod Environment",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-34092",
          "summary": "Eng Analysis RCA for UPS - elm-cp-cert-manager pipeline not leaving goggle certs in JKS",
          "type": "Bug",
          "status": "Re-finement",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39264",
          "summary": "Legal Hold initial load failed with error \"The file \"./custodian.tab\" does not exist or you don't have file access rights\"",
          "type": "Bug",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-35990",
          "summary": "Cognos SDK Pipeline Rollout validation to support environment Level SDK Version Configuration 11.1.7 FP8",
          "type": "Story",
          "status": "Re-finement",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 1
        },
        {
          "key": "ELM-32987",
          "summary": "Honeywell Qlik Replicate Setup Cleanup \u2013 Implementation and Validation",
          "type": "Story",
          "status": "Refined",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-33669",
          "summary": " [01]HCA (PH0081) - Rate Benchmark Create Manifest and Deployment Package",
          "type": "Story",
          "status": "Refined",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-34109",
          "summary": "DHL - Rate Benchmark Dashboard Setup",
          "type": "Story",
          "status": "Re-finement",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-39398",
          "summary": "Legal Hold initial load failure",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        }
      ]
    },
    "Minerva": {
      "total": 41,
      "tadComplete": 5,
      "tsComplete": 9,
      "bothComplete": 1,
      "tadPct": 12.195121951219512,
      "tsPct": 21.951219512195124,
      "issues": [
        {
          "key": "ELM-35778",
          "summary": "Matter Mapping for Passport client HCA in LVDWH",
          "type": "Story",
          "status": "Re-finement",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-38159",
          "summary": "Upgrade SSH and Network Communication Libraries to Address Security Vulnerabilities",
          "type": "Story",
          "status": "Refined",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39616",
          "summary": "Automate Scheduling of  Materialized Lake Views (MLVs) Refresh",
          "type": "Story",
          "status": "Re-finement",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39615",
          "summary": "Automate Materialized Lake View (MLV) Creation Using Notebook Scripts",
          "type": "Story",
          "status": "Re-finement",
          "tadFound": true,
          "tsFound": true,
          "totalPrs": 1
        },
        {
          "key": "ELM-39899",
          "summary": "Integrate API Connectivity with Pentaho Installation Job and Create Separate Job for DWH v23.2",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39900",
          "summary": "Integrate API Connectivity with Pentaho Installation Job and Create Separate Job for DWH v21.2",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39834",
          "summary": "Automate Lakehouse Maintenance Activities",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39277",
          "summary": "Sequence all the items in to single point of trigger",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39822",
          "summary": "Provide OOTB Semantic Model for Standard Reports",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39898",
          "summary": "Update MLV and Its Columns in Semantic Model",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39815",
          "summary": "Implement Alerting Mechanism for Semantic Model Processes",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-39812",
          "summary": "Update Logging mechanism maintaining Notebook script logs",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39278",
          "summary": "Azure pipelines update to support this deployment",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-39811",
          "summary": "Update RLS logic to Model",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39266",
          "summary": " Create relationships between the tables in semantic model",
          "type": "Story",
          "status": "Re-finement",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39614",
          "summary": "Inclusion of field parameters into Semantic Model",
          "type": "Story",
          "status": "Re-finement",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39276",
          "summary": "Create Passport UI and convert that as passport bundle",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-38803",
          "summary": "Passport - Data dictionary report -Measures and relationship",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-35907",
          "summary": "Passport Analytics data dictionary report - tables and columns",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-33724",
          "summary": "Enabler - Identify the source to control the mirroring process ",
          "type": "Story",
          "status": "Re-finement",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-39258",
          "summary": "Enabler - Create Lakehouse through scripts and identify the list of dependencies",
          "type": "Story",
          "status": "Re-finement",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 1
        },
        {
          "key": "ELM-28978",
          "summary": "Tenant Onboarding Pipeline for Hostname Normalization",
          "type": "Story",
          "status": "Re-finement",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-38163",
          "summary": "Upgrade Data Processing and Numerical Computing Libraries for Security Compliance",
          "type": "Story",
          "status": "Refined",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-28976",
          "summary": "Invoice Review Time - Report in mirroring",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-36626",
          "summary": "Create Azure DevOps pipeline for deploying T-SQL artifacts",
          "type": "Story",
          "status": "Refined",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-37214",
          "summary": "Merge summary tables latest changes to DWH 25.1 citi version",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-38802",
          "summary": "Set the Embedfast Tenant decsription through pipeline",
          "type": "Story",
          "status": "Re-finement",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-38962",
          "summary": "Content deployment for multiple clients",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-38162",
          "summary": "Upgrade Core Date/Time and Compatibility Utility Libraries",
          "type": "Story",
          "status": "Re-finement",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-38161",
          "summary": "Blackduck - Remediate Database Connectivity and System Monitoring Components",
          "type": "Story",
          "status": "Re-finement",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-38370",
          "summary": "LVDWH Contributor ETL Setup",
          "type": "Story",
          "status": "Refined",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-38160",
          "summary": "Update Cryptographic and Code Parsing Libraries for Security Compliance",
          "type": "Story",
          "status": "Refined",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-38369",
          "summary": "LegalView Warehouse Setup",
          "type": "Story",
          "status": "Refined",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-36627",
          "summary": "FDL T360 - Metadata Infrastructure Setup for CDC Buffer",
          "type": "Story",
          "status": "Refined",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39087",
          "summary": "FDL T360 - CDC Latency Mitigation in Incremental Load Pipeline",
          "type": "Story",
          "status": "Refined",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-38930",
          "summary": "Update semantic model and report for Invoice review details - Table chart",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-33120",
          "summary": "Update semantic model and report for Line-Item Analysis - Score cards and slicers",
          "type": "Story",
          "status": "Re-finement",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-28630",
          "summary": "Update semantic model and report for Line-Item Analysis - Net spend details",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-37213",
          "summary": "Merge control reports to DWH 25.1 citi version",
          "type": "Story",
          "status": "Refined",
          "tadFound": true,
          "tsFound": false,
          "totalPrs": 3
        },
        {
          "key": "ELM-31633",
          "summary": "Update semantic model and report for Invoice review details - Score cards and slicers",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39101",
          "summary": "FDL T360 - CDC Latency Mitigation After Full Load",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        }
      ]
    },
    "QA Perf Testing": {
      "total": 7,
      "tadComplete": 0,
      "tsComplete": 0,
      "bothComplete": 0,
      "tadPct": 0.0,
      "tsPct": 0.0,
      "issues": [
        {
          "key": "ELM-39933",
          "summary": "T360 | Develop JMeter Script for Company Search with Company Type, CRM and Currency",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39981",
          "summary": "T360 | BZM MCP Server",
          "type": "Story",
          "status": "Re-finement",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39934",
          "summary": "T360 | TO-10235 | BFF Test Executions",
          "type": "Story",
          "status": "Re-finement",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39392",
          "summary": "T360 | 25.4.5 (Phase-2) | Release Test Executions",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39470",
          "summary": "T360 - bff memory testing",
          "type": "Story",
          "status": "Re-finement",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39053",
          "summary": "T360 - 25.4.5 Sprint testing",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39326",
          "summary": "T360 | Document Service Testing",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        }
      ]
    },
    "Nike": {
      "total": 12,
      "tadComplete": 0,
      "tsComplete": 8,
      "bothComplete": 0,
      "tadPct": 0.0,
      "tsPct": 66.66666666666666,
      "issues": [
        {
          "key": "ELM-24006",
          "summary": "Create Azure DevOps Pipeline to Build/Package T-SQL Scripts",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-35550",
          "summary": "LVD > Apply Rate Limiting Patch for Passport Application",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 2
        },
        {
          "key": "ELM-35776",
          "summary": "Matter Mapping for UAL in LegalVIEW Data Warehouse",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-34762",
          "summary": "Matter mapping for ALAS Passport Client in LVDWH",
          "type": "Story",
          "status": "Resolved",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-34763",
          "summary": "Matter mapping for Argo Passport Client in LVDWH",
          "type": "Story",
          "status": "Resolved",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-34764",
          "summary": "Matter Mapping for Equitable Passport Client in LVDWH",
          "type": "Story",
          "status": "Resolved",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-34399",
          "summary": "Add 'Matter Description' and 'Long Matter Name' Columns to LegalVIEW Data Warehouse",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-35769",
          "summary": "Matter Mapping for Santander in LegalVIEW Data Warehouse",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-35779",
          "summary": "Matter Mapping for Bridgewater in LegalVIEW Data Warehouse",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-35780",
          "summary": "Matter Mapping for Centerpoint in LegalVIEW Data Warehouse",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-22453",
          "summary": "FDL - Update wrapper function to retrieve most recent data",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-35189",
          "summary": "Create a Daily Full Load of Passport CP Data for FDL Team",
          "type": "Story",
          "status": "Resolved",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        }
      ]
    },
    "Passport Matter Summary": {
      "total": 3,
      "tadComplete": 0,
      "tsComplete": 0,
      "bothComplete": 0,
      "tadPct": 0.0,
      "tsPct": 0.0,
      "issues": [
        {
          "key": "ELM-39928",
          "summary": " Identity Server Integration for OAuth 2.0",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39927",
          "summary": "Summary Display Modal",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39713",
          "summary": " Identity & AI Console Configuration UI",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        }
      ]
    },
    "PP Supernovas": {
      "total": 3,
      "tadComplete": 0,
      "tsComplete": 0,
      "bothComplete": 0,
      "tadPct": 0.0,
      "tsPct": 0.0,
      "issues": [
        {
          "key": "ELM-39272",
          "summary": "Backport Security Cache Fixes to Amtrak - 22.2.9 GA",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39271",
          "summary": "Backport Security Cache Fixes to Novartis - 22.2.2 GA",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-39270",
          "summary": "Backport Security Cache Fixes to Abbott - 23.2.1 GA",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        }
      ]
    },
    "Titans": {
      "total": 4,
      "tadComplete": 0,
      "tsComplete": 1,
      "bothComplete": 0,
      "tadPct": 0.0,
      "tsPct": 25.0,
      "issues": [
        {
          "key": "ELM-30856",
          "summary": "   ARD - URP: Architectural runway  ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-30855",
          "summary": "   SWAG - URP: Architectural runway ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        },
        {
          "key": "ELM-28132",
          "summary": "Finalize Semantic Model approach and create one POC model for Spend Overview dashboard ",
          "type": "Story",
          "status": "Closed",
          "tadFound": false,
          "tsFound": true,
          "totalPrs": 0
        },
        {
          "key": "ELM-39427",
          "summary": "Passport DWH Legal Holds module update to support Azure bulk load",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        }
      ]
    },
    "IDT": {
      "total": 1,
      "tadComplete": 0,
      "tsComplete": 0,
      "bothComplete": 0,
      "tadPct": 0.0,
      "tsPct": 0.0,
      "issues": [
        {
          "key": "ELM-12159",
          "summary": "Create pipeline to allow ad-hoc calls to the passport-dwh container.",
          "type": "Story",
          "status": "New",
          "tadFound": false,
          "tsFound": false,
          "totalPrs": 0
        }
      ]
    }
  }
};